﻿'Author: Costa Kokkotas
'Date: 2020-03-30
'File:lab5TextEditor.vb
'Description: This program is designed to work as a notepad
'           where the user can enter text and save it to a text file.
'           open a text file and have the contents displayed. The program
'           will also implement copy, cut, and paste features.


Option Strict On

Imports System.IO

Public Class frmLab5TextEditor

    'Global variables
    Dim path As String = "Untitled"
    Dim newText As Integer = 1
    Dim newOpen As Integer = 1
    Dim skipCode As Integer = 0
    Dim formClosedFromExit As Integer = 0

    ''' <summary>
    ''' The New button in the File tab
    ''' Allows the user to open a new instance of the note pad
    ''' and begin writing to a new file. The program will also
    ''' promt the user asking if they would like to save their previous work
    ''' if there is text or no file path assigned
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuFileNew_Click(sender As Object, e As EventArgs) Handles mnuFileNew.Click

        ConfirmClose()

    End Sub

    ''' <summary>
    ''' The Open button in the file tab
    ''' Allows the user to open any text file on their computer and import
    ''' the contents into the textbox
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuFileOpen_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click

        ConfirmClose()

        'If no file is being opened (CANCELLED) then exit event and return to the program 
        If newOpen = 0 Then
            skipCode = 1
        End If

        If skipCode <> 1 Then
            'openening an open file dialog
            If ofdOpen.ShowDialog = Windows.Forms.DialogResult.OK Then

                Me.Text = ofdOpen.FileName 'setting the title of the file to the path
                path = ofdOpen.FileName 'setting path variable to the path of the file opened

                'creating instance of StreamReader to read the file into the textbox then close the stream once it reaches the end of the file
                Dim openedFile As StreamReader
                openedFile = New StreamReader(New FileStream(path, FileMode.Open, FileAccess.Read))
                txtInput.Text = openedFile.ReadToEnd()
                openedFile.Close()

            End If
        End If

    End Sub

    ''' <summary>
    ''' The Save button in the File tab
    ''' Allows the user to save the file they are working on
    ''' if the file does not have a path assigned or is equal to the 
    ''' default path then it will prompt the user to select a path using
    ''' the save file dialog.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click

        If path = String.Empty Or path = "Untitled" Then

            'If the file has no path treat it as SaveAs function
            mnuFileSaveAs_Click(sender, e)

        Else

            'Else save the file to its path
            SaveFile()

        End If

    End Sub

    ''' <summary>
    ''' The SaveAs button in the File tab
    ''' Allows the user to save a new file, change the name of a file and save the contents that were in that file
    ''' using the save file dialog.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuFileSaveAs_Click(sender As Object, e As EventArgs) Handles mnuFileSaveAs.Click

        'creating filter for the user to select how they wish to save the file.
        sfdSave.Filter = "Text files (*.txt)|*.txt"

        'Opening save file dialog 
        If sfdSave.ShowDialog = Windows.Forms.DialogResult.OK Then

            'setting path to the location and name of the file that the user will decide.
            path = sfdSave.FileName

            'Displaying the path in the title bar
            Me.Text = path

            'save the file to the path created.
            SaveFile()
        End If

    End Sub

    ''' <summary>
    ''' The Exit button in the File tab
    ''' Allows the user to close the program. The program will also
    ''' promt the user asking if they would like to save their previous work
    ''' if there is text or no file path assigned
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click

        ConfirmClose()

        If (txtInput.Text = String.Empty And path = String.Empty Or path = "Untitled" And txtInput.Text = String.Empty) Then
            Me.Close()
        End If

    End Sub

    ''' <summary>
    ''' The Exit button on the form
    ''' Allows the user to close the program. The program will also
    ''' promt the user asking if they would like to save their previous work
    ''' if there is text or no file path assigned
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub frmlab5TextEditor_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        'skipping the rest of the code if the form was closed from the exit button on the menu strip
        If formClosedFromExit = 1 Then
            Exit Sub
        End If


        If (txtInput.Text <> String.Empty And path = String.Empty Or path = "Untitled" And txtInput.Text <> String.Empty) Then
            Dim choose As Object

            'closing message to user
            choose = MsgBox("Do you want to save changes to " + path + "?", MsgBoxStyle.YesNoCancel, path)

            'If user selects yes then save the file
            If CInt(choose) = MsgBoxResult.Yes Then

                If path = String.Empty Or path = "Untitled" Then

                    mnuFileSaveAs_Click(sender, e)

                Else

                    SaveFile()
                End If

                'else if user chooses cancel then close the message box and allow user to keep working
            ElseIf CInt(choose) = MsgBoxResult.Cancel Then

                e.Cancel = True

            End If
        End If

    End Sub

    ''' <summary>
    ''' The Copy button in the Edit tab
    ''' Allows the user to select text and send it to the clipboard to be used later
    ''' the text that was selected will remain there.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuEditCopy_Click(sender As Object, e As EventArgs) Handles mnuEditCopy.Click

        If txtInput.SelectedText <> String.Empty Then
            Clipboard.SetText(txtInput.SelectedText)
        End If

    End Sub

    ''' <summary>
    ''' The Cut Button in the Edit tab
    ''' Allows the user to select text and send it to the clipboard to be used later
    ''' the text that was selected will then be deleted from the textbox.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuEditCut_Click(sender As Object, e As EventArgs) Handles mnuEditCut.Click

        If txtInput.SelectedText <> String.Empty Then

            Clipboard.SetText(txtInput.SelectedText)

            If txtInput.SelectedText = Clipboard.GetText Then
                txtInput.SelectedText = String.Empty
            End If

        End If

    End Sub

    ''' <summary>
    ''' The Paste button in the Edit tab
    ''' Allows the user to paste the contents in the clipboard to text box.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuEditPaste_Click(sender As Object, e As EventArgs) Handles mnuEditPaste.Click

        If Clipboard.ContainsText Then

            txtInput.SelectedText = Clipboard.GetText

        End If

    End Sub

    ''' <summary>
    ''' The About button in the help tab
    ''' once the about button is clicked it will display the lab number that this program was made for
    ''' and the author of the program
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click

        MessageBox.Show("NETD" & vbCrLf & vbCrLf & "Lab5" & vbCrLf & vbCrLf & "C.Kokkotas", "About")

    End Sub

    ''' <summary>
    ''' Method to save a file.
    ''' </summary>
    Sub SaveFile()

        'creating instance of StreamWriter to write to the file then close the stream.
        Dim savedFile As StreamWriter
        savedFile = New StreamWriter(New FileStream(path, FileMode.Create, FileAccess.Write))
        savedFile.WriteLine(txtInput.Text)
        savedFile.Close()

    End Sub

    ''' <summary>
    ''' Method to confirm if the user wants to complete an action.
    ''' </summary>
    Sub ConfirmClose()

        newText = 1
        newOpen = 1
        skipCode = 0
        formClosedFromExit = 0


        If (txtInput.Text <> String.Empty And path = String.Empty Or path = "Untitled" And txtInput.Text <> String.Empty) Or (Me.Text = ofdOpen.FileName And txtInput.Text <> String.Empty) Then
            Dim choose As Object
            Dim sender As Object
            Dim e As EventArgs

            'closing message to user
            choose = MsgBox("Do you want to save changes to " + path + "?", MsgBoxStyle.YesNoCancel, path)

            'If user selects yes then save the file
            If CInt(choose) = MsgBoxResult.Yes Then

                If path = String.Empty Or path = "Untitled" Then

                    mnuFileSaveAs_Click(sender, e)

                Else

                    SaveFile()
                End If
            End If

            If CInt(choose) = MsgBoxResult.No Then

                'If a new text file is opened then
                If newText = 1 Then
                    txtInput.Text = String.Empty
                    path = "Untitled"
                End If

                If newOpen = 1 Then
                    Me.Text = "Untitled"
                End If

                'If the form is being closed by the exit button in the menu strip then
                If mnuFileExit.Pressed Then
                    formClosedFromExit = 1
                    Me.Close()
                End If
            End If

            If CInt(choose) = MsgBoxResult.Cancel Then

                'Cancelled dont change anything
                newText = 0

                'Cancelled dont change anything
                newOpen = 0

            End If
        End If

    End Sub

End Class
